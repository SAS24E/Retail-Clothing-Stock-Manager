Login username: admin
Password: admin123

How to create database: Create database named clothestock locally with the files Database.sql and UserTestData.sql

How to run: From the ClotheStockProject folder select the index.html file and select run file. All necessary files are provided. 

Link to web hosted version: clothingstockcheck.wuaze.com

